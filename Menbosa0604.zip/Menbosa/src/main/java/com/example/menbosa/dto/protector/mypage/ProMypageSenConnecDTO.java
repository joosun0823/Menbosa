package com.example.menbosa.dto.protector.mypage;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class ProMypageSenConnecDTO {
    private long senMemNum;
    private long proMemNum;
}
