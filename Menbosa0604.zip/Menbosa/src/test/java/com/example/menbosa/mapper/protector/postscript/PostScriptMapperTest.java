package com.example.menbosa.mapper.protector.postscript;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PostScriptMapperTest {

    @Test
    void selectListPostScript() {

    }
}